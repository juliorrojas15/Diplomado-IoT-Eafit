package com.app.iotsena;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    String TAG="Mensaje";
    //#########################################################################################     //Objetos del Layout
    EditText oetMensaje;
    Button obEnviar;
    TextView otvTexto;
    Switch osBotonApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //#####################################################################################     Relación de objetos con Layout
        oetMensaje = (EditText) findViewById(R.id.etMensaje);
        obEnviar = (Button) findViewById(R.id.bEnviar);
        otvTexto = (TextView) findViewById(R.id.tvTexto);
        osBotonApp = (Switch) findViewById(R.id.sBotonApp);

        //############ Accionamiento de Botones
        obEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fEnviar();
            }
        });
        osBotonApp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    fBotonApp(true);
                }
                else{
                    fBotonApp(false);
                }
            }
        });

        // Read from the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Mensaje a app");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Integer value = dataSnapshot.getValue(Integer.class);
                if (!(value==null)){
                    otvTexto.setText("Contador: "+value);
                    Log.d(TAG, "Value is: " + value);
                }
                else{
                    otvTexto.setText("El dato no existe");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    void fEnviar(){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        myRef.setValue(oetMensaje.getText().toString());

    }

    void fBotonApp(boolean xEstadoVar){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Boton App");

        myRef.setValue(xEstadoVar);

    }
}